// Scroll reveal
const reveals = document.querySelectorAll('section, .service-card, .work-item, .stat');
reveals.forEach(el => el.classList.add('reveal'));

const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); } });
}, { threshold: 0.1 });

reveals.forEach(el => observer.observe(el));

// Nav scroll style
window.addEventListener('scroll', () => {
  const nav = document.querySelector('.nav');
  nav.style.background = window.scrollY > 60
    ? 'rgba(10,10,10,0.95)'
    : 'linear-gradient(to bottom, rgba(10,10,10,0.9), transparent)';
});

// Form submit
function handleSubmit(e) {
  e.preventDefault();
  const btn = e.target.querySelector('.submit-btn');
  btn.textContent = '已收到，我们将尽快联系您 ✓';
  btn.style.background = '#2a2a2a';
  btn.style.color = '#c8a96e';
  btn.disabled = true;
}
